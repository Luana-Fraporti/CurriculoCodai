var nome= "Luana Fraporti";
var cargo= "CTO-Growdev"

var nomehtml = document.gatelementebyid("nome-no-html");
var cargohtml = document.gatelementebyid("cargo-no-html");
var texto1 = document.gatelementebyid("texto-1");
var texto2 = document.gatelementebyid("texto-2");

function colocarnomenohtml (nome){
nomehtml.innerhtml = nome
}

function colocarcargonohtml(cargo){
cargohtml.innerhtml = cargo;
}

function lojarnome() {
    console.log(nome);
}

function clicknoprojetos(){
    console.log ("clicou no botao projetos");
    texto2.style.display = "block";
    texto1.style.display = "nome";
}

function clicknosobre (){
    console.log("clicou no botao sobre");
    texto1.style.display = "block";
    texto2.style.display = "nome"
}

colocarnomenohtml(Nome);
colocarcargonohtml(cargo);